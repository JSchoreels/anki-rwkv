"""One R01 screen with nested random cohorts and disjoint held-out users."""

from argparse import ArgumentParser
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.experiment_provenance import process_provenance
from scripts.gpu_r01_policy import POLICY, accepted_reference, read_reference, require_active, streak, round_budget_fields
from scripts import run_gpu_batch1 as shared

BASE = ROOT / "artifacts/retraining/gpu-retrain-r01"
# GPU_RETRAIN_LOOP.md speed target (human request 2026-10-12: 20% -> 5%).
TARGET_THROUGHPUT_GAIN = 0.05
COHORT = BASE / "cohorts-user-holdout-v1.json"
OPTIONS = {"control": {}, "F01": {"prefetch_users": True},
           "F03": {"worker_local": True, "packed_ipc": True},
           "F04": {"async_transfer": True},
           "F01-F06": {"prefetch_users": True, "reduced_sync": True},
           "F01-F16": {"prefetch_users": True, "preparation_workers": 8},
           "F01-F16-F14": {"prefetch_users": True, "preparation_workers": 8, "gpu_packed_features": True},
           "F01-F16-F14-F03": {"prefetch_users": True, "preparation_workers": 8, "gpu_packed_features": True, "packed_ipc": True},
           "F01-F16-F14-F03-F04": {"prefetch_users": True, "preparation_workers": 8, "gpu_packed_features": True, "packed_ipc": True, "async_transfer": True}}

# Opt-in CPU preparation extensions; retained configurations are unchanged.
for _reference in ("F01", "F01-F16-F14-F03-F04"):
    for _suffix, _extensions in (("F02", {"preprocessing_cache": True}),
                                  ("F19", {"batched_id_encodings": True}),
                                  ("F02-F19", {"preprocessing_cache": True, "batched_id_encodings": True})):
        OPTIONS[_reference + "-" + _suffix] = {**OPTIONS[_reference], **_extensions}


class R01SourceWatch(shared.SourceWatch):
    def __init__(self, provenance):
        super().__init__(provenance)
        with ZipFile(ROOT / provenance["source_archive"]) as archive:
            manifest = json.loads(archive.read("source-manifest.json"))["files"]
        for name in ("scripts/run_gpu_r01.py", "scripts/gpu_r01_training.py", "scripts/gpu_r01_prefetch.py", "scripts/gpu_r01_sync.py", "scripts/gpu_r01_staging.py", "scripts/gpu_b01.py", "scripts/gpu_resource_monitor.py", "scripts/gpu_r01_policy.py", "scripts/gpu_preprocessing_cache.py", "scripts/gpu_preprocessing_stage.py", "scripts/gpu_id_encodings.py", "scripts/gpu_r01_update.py", "scripts/gpu_packed_encodings.py", "scripts/gpu_optimizations.py", "scripts/gpu_batch1.py", "rwkv/prepare_batch.py"):
            self.hashes[name] = manifest[name]
        for name in ("scripts/gpu_r01_packing.py", "scripts/gpu_r01_samples.py"):
            self.hashes[name] = manifest[name]
        if "scripts/gpu_scatter_orders.py" in manifest:
            self.hashes["scripts/gpu_scatter_orders.py"] = manifest["scripts/gpu_scatter_orders.py"]
        # F31 kernels exist from iteration 0021; older archives keep their original watch set.
        for name in ("scripts/gpu_row_tiles.py", "scripts/kernels/rwkv_row_tiles_exact.cu", "rwkv/model/exact_group_norm.py",
                     "rwkv/model/exact_index.py", "rwkv/model/nvrtc.py"):
            if name in manifest:
                self.hashes[name] = manifest[name]
        self.implementation_sha256 = hashlib.sha256(json.dumps(self.hashes, sort_keys=True).encode()).hexdigest()
        self.check()


def prepare(output, iteration="0002", previous=None, plan=None, resume_prepared=False, round_authorization=None, round_iterations=None,
            loss_ceiling=None):
    import numpy as np
    # A new round needs the human request quoted in the protocol; stops before it stay recorded.
    new_round = resume_prepared or bool((round_authorization or "").strip())
    if new_round and previous is None:
        raise ValueError("Resuming prepared work requires preserved previous results")
    if (output / "protocol.json").exists():
        raise FileExistsError("Preserve the frozen iteration; use a new output for a new round")
    previous_comparison = None
    previous_outputs = {}
    fixed_fields = round_budget_fields(iteration, authorization=round_authorization, budget=round_iterations)
    models = ["baseline", "expertium"]
    if previous is None:
        from scripts.gpu_r01_policy import recorded_cases
        if any(case.get("status") == "complete" and not case.get("smoke_only") for _, case, _ in recorded_cases(ROOT)):
            raise ValueError("Recorded baselines already exist; continue with --previous instead of starting another baseline round")
    if previous is not None:
        previous = (ROOT / previous).resolve()
        old_protocol = json.loads((previous / "protocol.json").read_text())
        if not new_round:
            fixed_fields = round_budget_fields(iteration, old_protocol)
        if fixed_fields:
            require_active("round", 0, {"iteration": iteration, **fixed_fields})
        previous_comparison = json.loads((previous / "comparison.json").read_text())
        previous_outputs = {model: previous for model in previous_comparison["comparisons"]}
        if new_round:
            for model in ("baseline", "expertium"):
                if model not in previous_comparison["comparisons"]:
                    for candidate in sorted(BASE.glob("iteration-*/comparison.json"), reverse=True):
                        if candidate.parent.name > previous.name:
                            continue
                        item = json.loads(candidate.read_text())["comparisons"].get(model)
                        if item:
                            previous_outputs[model] = candidate.parent
                            previous_comparison["comparisons"][model] = item
                            break
        models = [model for model in models if model in previous_comparison["comparisons"]
                  and (new_round or fixed_fields or streak(previous_comparison["comparisons"][model]) < 3)]
        if not models:
            raise RuntimeError("R01 stopped: both models reached three consecutive iterations without a 20% gain")
    provenance = process_provenance()
    if not COHORT.exists():
        counts_path = ROOT / "artifacts/diagnostics/check-temp/first-5000-review-counts.json"
        counts = json.loads(counts_path.read_text())
        old = json.loads((ROOT / "artifacts/benchmarks/gpu-baseline-b01/protocol.json").read_text())
        reserved = old["independent_final_test_users"]
        data = ROOT / old["dataset_path"]
        manifest = json.loads((data / "download_manifest.json").read_text())
        if manifest["revision"] != counts["revision"]:
            raise ValueError("Saved counts and pinned dataset revisions differ")
        ordered = sorted(range(1, 5001), key=lambda user: (counts["per_user"][str(user)], user))
        deciles = {int(user): index + 1 for index, group in enumerate(np.array_split(ordered, 10)) for user in group}
        rng = np.random.default_rng(20261011)
        sampled = [int(user) for user in rng.permutation([user for user in range(1, 5001) if user not in set(reserved)])[:500]]
        train, heldout, stages = [], [], {}
        previous_count = 0
        for count in (100, 250, 500):
            added = sampled[previous_count:count]
            # Stable roles across nested cohorts; each added block is 80/20.
            train.extend(added[:len(added) * 4 // 5])
            heldout.extend(added[len(added) * 4 // 5:])
            def rows(ids):
                return [{"user_id": user, "history_decile": deciles[user],
                         "available_reviews": counts["per_user"][str(user)],
                         "train_range": [0, counts["per_user"][str(user)]],
                         "validation_range": [0, counts["per_user"][str(user)]]} for user in sorted(ids)]
            stages[str(count)] = {"users": count, "training_users": sorted(train), "heldout_users": sorted(heldout),
                                  "rows": rows(train), "evaluation_rows": rows(heldout),
                                  "training_reviews": sum(counts["per_user"][str(user)] for user in train),
                                  "validation_reviews": sum(counts["per_user"][str(user)] for user in heldout)}
            previous_count = count
        shared.atomic_json(COHORT, {"sampling_seed": 20261011, "sampling": "random without replacement from IDs 1-5000, excluding the preserved independent final-test cohort",
                                   "dataset_revision": counts["revision"], "dataset_path": old["dataset_path"],
                                   "counts_source": counts_path.relative_to(ROOT).as_posix(),
                                   "counts_sha256": hashlib.sha256(counts_path.read_bytes()).hexdigest(),
                                   "independent_final_test_users": reserved, "stages": stages,
                                   "prepared_utc": datetime.now(timezone.utc).isoformat(), "provenance": provenance})
    cohort = json.loads(COHORT.read_text())
    stage = cohort["stages"]["100"]
    for count, value in cohort["stages"].items():
        train, heldout = set(value["training_users"]), set(value["heldout_users"])
        if train & heldout or len(train) + len(heldout) != int(count) or len(heldout) * 5 != int(count):
            raise ValueError("Cohort roles/counts are invalid")
        if (train | heldout) & set(cohort["independent_final_test_users"]):
            raise ValueError("Independent final-test overlap")
    output.mkdir(parents=True, exist_ok=True)
    protocol = {**stage, "protocol_status": "frozen before experiments", "iteration": iteration,
                "authorization": "2026-10-11: user requested exactly one iteration of current docs/GPU_RETRAIN_LOOP.md",
                "cohort_file": COHORT.relative_to(ROOT).as_posix(), "cohort_sha256": hashlib.sha256(COHORT.read_bytes()).hexdigest(),
                "dataset_path": cohort["dataset_path"], "dataset_revision": cohort["dataset_revision"],
                "evaluation_users": len(stage["heldout_users"]), "training_user_count": len(stage["training_users"]),
                "evaluation": "unseen users; complete histories, chunked at 128 reviews; no gradient updates or fitting on held-out users",
                "holdout": "20% disjoint user holdout; mask labels pointing outside the retained full history",
                "seeds": [2025], "sampling_seed": cohort["sampling_seed"], "models": models,
                "loop_policy": POLICY,
                "training": {"epochs": 1, "chunk_reviews": 128, "baseline_chunks_workers": [128, 4],
                             "expertium_chunks_workers": [256, 6], "dtype": "BF16", "master_dtype": "FP32",
                             "peak_lr": 7e-4, "warmup_updates": 5, "clip": 0.5, "cpu_threads": 4,
                             "prefetch_depth": "2 times preparation workers", "gpu_memory_fraction": 0.95,
                             "initialization": "fresh seed-paired weights and AdamW; no checkpoint reuse"},
                "execution_mode": {"torch_graph_executor_optimize": False, "deterministic_algorithms": True,
                                   "CUBLAS_WORKSPACE_CONFIG": ":4096:8", "wkv_tile": 32},
                "planned_updates": {model: sum((row["available_reviews"] + chunks * 128 - 1) // (chunks * 128) for row in stage["rows"])
                                    for model, chunks in (("baseline", 128), ("expertium", 256))},
                "budget": "two fresh baselines plus one profile-selected candidate per architecture; one training seed; no larger stages in this iteration",
                "eligible_tracks": {key: value for key, value in OPTIONS.items() if key != "control"},
                "acceptance": {"relative_loss_limit": 0.01, "baseline_loss_limit": 0.02, "target_throughput_gain": TARGET_THROUGHPUT_GAIN,
                               "exact_promotion_rule": "replicated_blocks",
                               # Human approval 2026-10-13; calibration in iteration 0047.
                               "replicated_blocks": {"estimator": "trimmed time-weighted per-update wall gain", "mad_limit": 5.0,
                                                     "calibrated_sd_percent": 1.01, "calibration": "iteration-0047",
                                                     "looks": [2, 4, 6], "boundary_z": 1.9927, "one_sided_alpha": 0.05,
                                                     "max_blocks": 8, "extend_only_when_mean_positive": True},
                               "metrics": "Curve/Instant binary logloss, label-weighted and user-averaged, each separately",
                               "parity": "compare update metadata/loss/norm, initial/final weight hashes and held-out input hashes; exact final weights and scores preferred",
                               "resamples": 10000, "bootstrap_seed": 20261012, "family_tests": 8, "alpha": 0.05,
                               "quality_gate": "measured relative loss regression <=1%; confidence intervals reported separately; original baseline <=2% preferred",
                               "status": "preliminary only; 20 distinct evaluation users do not satisfy the 500-evaluation-user validation gate"},
                "timing": "raw review presentations/s uses complete training including loads, preparation/worker startup+shutdown, transfers, updates and logs; setup/primer/save/evaluation/process wall recorded separately",
                "frozen_utc": datetime.now(timezone.utc).isoformat(), "preparation_provenance": provenance,
                "implementation_sha256": R01SourceWatch(provenance).implementation_sha256}
    if previous is not None:
        old_protocol = json.loads((previous / "protocol.json").read_text())
        if old_protocol["cohort_sha256"] != protocol["cohort_sha256"]:
            raise ValueError("Continuation must reuse the exact frozen cohort")
        references, controls = {}, {}
        for model in protocol["models"]:
            model_previous = previous_outputs[model]
            model_old_protocol = json.loads((model_previous / "protocol.json").read_text())
            accepted = accepted_reference(model_previous, model, ROOT)
            incumbent, _ = read_reference(accepted, ROOT)
            controls[model] = incumbent["track"]
            baseline = model_old_protocol.get("references", {}).get(model, {}).get("original_baseline")
            if baseline is None:
                from scripts.gpu_r01_policy import result_metadata
                baseline = result_metadata(model_previous / model / "control/result.json", ROOT)
            read_reference(baseline, ROOT)
            references[model] = {"previous": accepted, "original_baseline": baseline}
        protocol.update(control_tracks=controls,
                        previous_iteration=old_protocol["iteration"], references=references,
                        authorization="2026-10-11: user requested one new iteration",
                        budget="reuse recorded original baselines and accepted runs; one selected candidate per active model; focused checks as needed; no larger cohort")
        protocol["acceptance"]["family_tests"] = len(models) * 4 * 2
        protocol["acceptance"]["comparisons"] = "measured regression vs previous accepted run <=1%; original baseline <=2% preferred; uncertainty reported separately"
        protocol["prior_no_20_percent_gain_streak"] = {model: previous_comparison["comparisons"][model].get("no_20_percent_gain_streak", previous_comparison["comparisons"][model].get("no_20_percent_gain_streak_after_this_iteration", 0)) for model in protocol["models"]}
        if new_round and not resume_prepared:
            protocol.update(round_start_iteration=iteration, round_authorization=round_authorization.strip(),
                            historical_no_gain_streak=dict(protocol["prior_no_20_percent_gain_streak"]))
            protocol["prior_no_20_percent_gain_streak"] = {model: 0 for model in models}
            protocol["authorization"] = protocol["round_authorization"]
            protocol["budget"] = "New user-authorized round; reuse recorded original baselines and accepted runs; one selected candidate per active model; fixed 100-user cohort, no broader validation; three-miss stop applies within this round"
        elif resume_prepared:
            protocol.update(round_start_iteration=iteration,
                            round_authorization="2026-10-12 human request: Ok I closed the game, you can do the next iterations with the prepared changes",
                            historical_no_gain_streak=dict(protocol["prior_no_20_percent_gain_streak"]))
            protocol["prior_no_20_percent_gain_streak"] = {model: 0 for model in models}
            protocol["authorization"] = protocol["round_authorization"]
            protocol["budget"] = "Prepared F19 encoding and F02 preprocessing-cache iterations; fixed 100-user cohort, no broader validation; three-miss stop applies within this explicitly resumed round"
        elif old_protocol.get("round_start_iteration"):
            protocol["round_start_iteration"] = old_protocol["round_start_iteration"]
            protocol["round_authorization"] = old_protocol["round_authorization"]
        if fixed_fields:
            protocol.update(fixed_fields)
            protocol["budget"] = (f"Explicit human count: iteration {fixed_fields['round_iteration_index']} of "
                                  f"{fixed_fields['round_iteration_budget']}; complete the count despite consecutive misses; "
                                  "reuse accepted references; fixed cohort; no broader validation")
        from scripts.gpu_r01_policy import round_loss_limit
        round_start = new_round and not resume_prepared
        loss_limit = round_loss_limit(old_protocol, new_round=round_start, requested=loss_ceiling)
        if loss_limit is not None:
            # Regressions within the ceiling may be promoted, bounded against the round's first reference too,
            # so successive small regressions cannot accumulate beyond the ceiling within one round.
            protocol["acceptance"]["regressions_within_limit_promotable"] = True
            for model in protocol["models"]:
                inherited = None if round_start else old_protocol.get("references", {}).get(model, {}).get("round_start")
                if not round_start and inherited is None:
                    raise ValueError("Round ceiling continuation lacks its frozen round-start reference")
                protocol["references"][model]["round_start"] = inherited or protocol["references"][model]["previous"]
            # Human-set ceiling for this round (2026-10-12: start at 0.1%, raise later); applies to all four losses.
            percent = f"{100 * loss_limit:g}%"
            protocol["round_relative_loss_limit"] = loss_limit
            protocol["acceptance"]["relative_loss_limit"] = loss_limit
            protocol["acceptance"]["quality_gate"] = f"measured relative loss regression <={percent} (round ceiling); confidence intervals reported separately; original baseline <=2% preferred"
            protocol["acceptance"]["comparisons"] = f"measured regression vs previous accepted run <={percent} (round ceiling); original baseline <=2% preferred; uncertainty reported separately"
        previous_target = old_protocol.get("acceptance", {}).get("target_throughput_gain", 0.20)
        if previous_target != TARGET_THROUGHPUT_GAIN and not new_round:
            from scripts.gpu_r01_policy import recount_streak
            protocol["target_change"] = {"previous_target_throughput_gain": previous_target,
                                         "target_throughput_gain": TARGET_THROUGHPUT_GAIN,
                                         "recorded_streak": dict(protocol["prior_no_20_percent_gain_streak"]),
                                         "reason": "GPU_RETRAIN_LOOP.md target changed by human request; the current round's miss count is re-derived under the new target, recorded decisions unchanged"}
            protocol["prior_no_20_percent_gain_streak"] = {model: recount_streak(ROOT, model, protocol.get("round_start_iteration"), old_protocol["iteration"], 100 * TARGET_THROUGHPUT_GAIN)
                                                           for model in models}
        protocol["resource_retuning_pending"] = {model: previous_comparison["comparisons"][model].get("resource_retuning_pending", False) for model in models}
        protocol["retuning_candidates"] = {model: previous_comparison["comparisons"][model]["retuning_candidate"]
                                          for model in models if protocol["resource_retuning_pending"][model]}
        if plan is None:
            if any(protocol["resource_retuning_pending"].values()):
                raise ValueError("Investigate the recorded resource-saving candidate and provide a retuning plan")
            candidates = {model: "F01-F06" if model == "baseline" else "F01-F16" for model in models}
            proposed = {"control_tracks": controls, "candidate_tracks": candidates,
                        "case_options_by_model": {model: {controls[model]: read_reference(references[model]["previous"], ROOT)[0]["options"],
                                                          candidates[model]: OPTIONS[candidates[model]]} for model in models},
                        "case_explanations": {}}
        else:
            plan_path = (ROOT / plan).resolve()
            proposed = json.loads(plan_path.read_text())
            protocol.update(plan_path=plan_path.relative_to(ROOT).as_posix(), plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest())
        if "models" in proposed:
            excluded = [model for model in models if model not in proposed["models"]]
            if not proposed.get("model_scope_reason") and excluded:
                raise ValueError("Excluding an active model requires the recorded human reason")
            models[:] = [model for model in models if model in proposed["models"]]
            protocol["models"] = list(models)
            protocol["paused_models"] = {model: proposed["model_scope_reason"] for model in excluded}
            protocol["acceptance"]["family_tests"] = len(models) * 4 * 2
        protocol["retuning_dispositions"] = proposed.get("retuning_dispositions", {})
        for model, review in protocol["retuning_dispositions"].items():
            if model in protocol["retuning_candidates"] and review.get("decision") == "continue from accepted reference":
                if not review.get("evidence"):
                    raise ValueError("Retuning disposition requires recorded resource evidence")
                protocol["retuning_candidates"].pop(model)
        for model in models:
            if resume_prepared and not any(proposed["case_options_by_model"][model][proposed["candidate_tracks"][model]].get(key)
                                           for key in ("preprocessing_cache", "batched_id_encodings")):
                raise ValueError("Prepared-round resumption is limited to F02 cache/F19 encoding candidates")
            if proposed["control_tracks"][model] != controls[model]:
                raise ValueError("Plan must retain the previous accepted run")
            if proposed["candidate_tracks"][model] == controls[model]:
                raise ValueError("Choose an improvement candidate rather than rerunning the accepted configuration")
            if set(proposed["case_options_by_model"][model]) != {controls[model], proposed["candidate_tracks"][model]}:
                raise ValueError("Plan must describe the accepted configuration and one candidate")
            incumbent, _ = read_reference(references[model]["previous"], ROOT)
            if proposed["case_options_by_model"][model][controls[model]] != incumbent["options"]:
                raise ValueError("Accepted configuration changed")
        protocol.update(candidate_tracks={m: proposed["candidate_tracks"][m] for m in models},
                        case_options_by_model={m: proposed["case_options_by_model"][m] for m in models},
                        case_explanations=proposed.get("case_explanations", {}),
                        eligible_tracks={m: proposed["candidate_tracks"][m] for m in models},
                        check_policy="reuse applicable profiles; focused smoke checks for changed code, no mandatory paired repeats")
    # Predeclare which gains count as faster rather than run-to-run variation.
    from scripts.gpu_r01_policy import planned_updates
    protocol["planned_updates"] = {model: planned_updates(
        protocol["rows"], protocol["case_options_by_model"][model][protocol["candidate_tracks"][model]].get(
            "batch_chunks", protocol["training"][model + "_chunks_workers"][0]), protocol["training"]["chunk_reviews"],
        pack_users=protocol["case_options_by_model"][model][protocol["candidate_tracks"][model]].get("pack_users", False))
        for model in protocol["models"]} if "candidate_tracks" in protocol else protocol["planned_updates"]
    from scripts.gpu_r01_policy import speed_noise_band
    protocol["acceptance"]["speed_noise_band"] = {model: speed_noise_band(ROOT, model) for model in protocol["models"]}
    protocol["loop_sha256"] = hashlib.sha256((ROOT / "docs/GPU_RETRAIN_LOOP.md").read_bytes()).hexdigest()
    (output / "loop-definition.md").write_bytes((ROOT / "docs/GPU_RETRAIN_LOOP.md").read_bytes())
    shared.atomic_json(output / "protocol.json", protocol)
    print(json.dumps({"protocol": str(output / "protocol.json"), "train_users": 80, "heldout_users": 20,
                      "training_reviews": stage["training_reviews"], "heldout_reviews": stage["validation_reviews"],
                      "planned_updates": protocol["planned_updates"]}))


def run_case(args, output):
    import psutil
    if not (ROOT / "isolation.json").exists():
        from scripts.run_isolated_gpu_r01 import launch_case
        return launch_case(args, output, root=ROOT)
    ticket_path = os.environ.get("GPU_R01_LAUNCH_TICKET")
    controller = os.environ.get("GPU_R01_CONTROLLER_ROOT")
    if not ticket_path or not controller:
        raise ValueError("Start frozen R01 code through the current workspace launcher")
    ticket_path = Path(ticket_path).resolve()
    controller = Path(controller).resolve()
    if not ticket_path.is_relative_to(controller / "artifacts"):
        raise ValueError("Launch ticket must remain under controller artifacts")
    ticket = json.loads(ticket_path.read_text(encoding="utf-8"))
    if (ticket["model"], ticket["track"], ticket["smoke"], ticket["output"], ticket["runtime"]) != (
            args.model, args.track, args.smoke, output.relative_to(ROOT).as_posix(), ROOT.relative_to(controller).as_posix()):
        raise ValueError("Launch ticket differs from this request")
    from scripts.gpu_r01_policy import effective_loop
    effective_loop(controller / ticket["output"], controller, current=True)
    protocol = json.loads((output / "protocol.json").read_text())
    if hashlib.sha256((output / "protocol.json").read_bytes()).hexdigest() != ticket["protocol_sha256"]:
        raise ValueError("Frozen protocol differs from the live launch ticket")
    require_active(args.model, protocol.get("prior_no_20_percent_gain_streak", {}).get(args.model, 0), protocol)
    if args.model not in protocol["models"]:
        raise ValueError("Model is outside the active iteration")
    control_track = protocol.get("control_tracks", {}).get(args.model, protocol.get("control_track", "control"))
    if "references" in protocol and args.track == control_track and not ticket.get("repeat_reason"):
        raise ValueError("Reuse the recorded accepted run; a control rerun needs a separate justified protocol")
    os.environ["GPU_BATCH1_DATA_PATH"] = os.environ.get("GPU_R01_SHARED_DATA_PATH", protocol["dataset_path"])
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = protocol["execution_mode"]["CUBLAS_WORKSPACE_CONFIG"]
    os.environ["CUPY_CACHE_DIR"] = str(ROOT / "artifacts/cache/cupy-cache")
    provenance = process_provenance()
    if R01SourceWatch(provenance).implementation_sha256 != protocol["implementation_sha256"]:
        raise RuntimeError("Training source changed after protocol freeze; preserve this iteration")
    options = protocol.get("case_options_by_model", {}).get(args.model, protocol.get("case_options", OPTIONS))
    if args.track not in options:
        raise ValueError("Track is outside the frozen iteration budget")
    if args.track != control_track and not args.smoke and args.track not in protocol.get("study_tracks", {}).get(args.model, []):
        selection = json.loads((output / "selection.json").read_text())
        if selection[args.model]["track"] != args.track:
            raise ValueError("Candidate was not selected from baseline resource evidence")
    folder = output / args.model / args.track
    if (folder / "result.json").exists():
        raise FileExistsError("Preserve every prior case; no implicit overwrite")
    if args.smoke:
        output = output / "functional-smoke-v1"
        folder = output / args.model / args.track
        if (folder / "result.json").exists():
            raise FileExistsError("Preserve the previous smoke")
        shared.atomic_json(output / "protocol.json", protocol)
    lock = ROOT / "artifacts/gpu-r01.lock"
    other = ROOT / "artifacts/gpu-batch1.lock"
    if other.exists() and psutil.pid_exists(json.loads(other.read_text())["pid"]):
        raise RuntimeError("Another GPU suite is active")
    with lock.open("x") as file:
        json.dump({"pid": os.getpid(), "output": output.relative_to(ROOT).as_posix()}, file)
    import torch
    from scripts import gpu_batch1, gpu_power, gpu_r01_training
    from scripts.gpu_resource_monitor import ResourceMonitor
    if torch.cuda.is_initialized():
        raise RuntimeError("R01 requires a fresh CUDA process")
    # F22 candidates may run the regime used by ordinary training: TorchScript fusion
    # on and/or non-deterministic kernels. Bit-exact parity is then not expected.
    case = options[args.track]
    actual_mode = {**protocol["execution_mode"],
                   "torch_graph_executor_optimize": bool(case.get("jit_optimize", False)),
                   "deterministic_algorithms": not case.get("nondeterministic", False),
                   "fill_uninitialized_memory": not case.get("skip_uninitialized_fill", False)}
    torch._C._set_graph_executor_optimize(actual_mode["torch_graph_executor_optimize"])
    torch.use_deterministic_algorithms(actual_mode["deterministic_algorithms"], warn_only=False)
    torch.utils.deterministic.fill_uninitialized_memory = actual_mode["fill_uninitialized_memory"]
    gpu_batch1.TRACKS = options
    gpu_r01_training.SourceWatch = R01SourceWatch
    if options[args.track].get("gpu_packed_features"):
        from scripts.gpu_r01_staging import training_batches
        from scripts.gpu_b01 import transfer_batches
        gpu_batch1.training_batches = training_batches
        gpu_batch1.transfer_batches = transfer_batches
    elif options[args.track].get("prefetch_users"):
        from scripts.gpu_r01_prefetch import training_batches
        gpu_batch1.training_batches = training_batches
    args.output = output.relative_to(ROOT).as_posix()
    args.expected_source = protocol["implementation_sha256"]
    saves = []
    save = torch.save
    def measured_save(value, destination, *values, **kwargs):
        started = time.perf_counter()
        try:
            return save(value, destination, *values, **kwargs)
        finally:
            if Path(destination).name == "master.pth":
                saves.append({"elapsed_seconds": time.perf_counter() - started, "path": Path(destination).relative_to(ROOT).as_posix()})
    try:
        with ResourceMonitor(folder) as monitor:
            power = gpu_power.limited_gpu
            gpu_power.limited_gpu = lambda *values: monitor.training_phase(power, *values)
            torch.save = measured_save
            try:
                code = gpu_r01_training.run_case(args)
            finally:
                gpu_power.limited_gpu = power
                torch.save = save
        result = json.loads((folder / "result.json").read_text())
        result.update(iteration=protocol["iteration"], execution_mode=actual_mode, checkpoint_saves=saves,
                      protocol_sha256=hashlib.sha256((output / "protocol.json").read_bytes()).hexdigest(),
                      process_wall_seconds=time.time() - psutil.Process().create_time(),
                      evaluation_scope=protocol["evaluation"], quality_status="preliminary screen; broader validation pending")
        shared.atomic_json(folder / "result.json", result)
        print(json.dumps({key: result.get(key) for key in ("model", "track", "status", "training_seconds", "reviews_per_second", "evaluation", "error")}))
        return code
    finally:
        lock.unlink(missing_ok=True)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("artifacts/retraining/gpu-retrain-r01/iteration-0002"))
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--iteration", default="0002")
    parser.add_argument("--previous", type=Path)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--resume-prepared", action="store_true", help="Record explicit user resumption for prepared F02/F19 work")
    parser.add_argument("--round-authorization", help="Quoted human request that starts a new round after recorded stops")
    parser.add_argument("--round-iterations", type=int, help="Explicit human iteration count; overrides consecutive-miss stopping for this round")
    parser.add_argument("--loss-ceiling", type=float, help="Round relative loss ceiling as a fraction (0.001 = 0.1%%); frozen at round start, inherited by later iterations")
    parser.add_argument("--case", action="store_true")
    parser.add_argument("--model", choices=("baseline", "expertium"))
    parser.add_argument("--track", default="control")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--repeat-reason", help="Concrete incompatibility or repaired failure requiring a repeat")
    parser.add_argument("--check-reason", help="Changed behaviour this focused smoke verifies")
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / "artifacts"):
        parser.error("Output must remain under workspace artifacts")
    if args.prepare:
        return prepare(output, args.iteration, args.previous, args.plan, args.resume_prepared, args.round_authorization, args.round_iterations,
                       args.loss_ceiling)
    if args.case and args.model:
        return run_case(args, output)
    parser.error("Choose --prepare or --case --model")


if __name__ == "__main__":
    raise SystemExit(main())
