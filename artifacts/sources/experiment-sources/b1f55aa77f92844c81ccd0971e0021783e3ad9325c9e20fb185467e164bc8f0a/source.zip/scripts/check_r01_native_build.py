"""Compile the host-only native dispatcher with scoped MSVC/SDK environment; no GPU."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    from rwkv.model.native_launch import build_identity, BUILD_FLAGS
    from scripts.experiment_provenance import process_provenance
    import torch
    identity,key=build_identity()
    destination=ROOT/'artifacts/cache/r01-native'/key
    destination.mkdir(parents=True,exist_ok=True)
    if (destination/'build.json').exists():
        metadata=json.loads((destination/'build.json').read_text(encoding='utf-8'))
        if metadata['identity']!=identity or hashlib.sha256((destination/'native_launch.dll').read_bytes()).hexdigest()!=metadata['binary_sha256']:
            raise RuntimeError('Existing native cache build differs; preserve it')
    else:
        candidates=[Path('C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Auxiliary/Build/vcvars64.bat')]
        vcvars=next((path for path in candidates if path.is_file()),None)
        if vcvars is None:raise RuntimeError('Authorized Build Tools installation is not yet available')
        captured=subprocess.run(['cmd.exe','/d','/s','/c',f'call "{vcvars}" >nul && set'],capture_output=True,text=True,check=True)
        environment=dict(os.environ)
        for line in captured.stdout.splitlines():
            name,sep,value=line.partition('=')
            if sep and name:environment[name]=value
        torch_root=Path(torch.__file__).parent
        cuda_root=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.4')
        if environment.get('VCToolsVersion','').rstrip('\\/') != identity['msvc_version'] or environment.get('WindowsSDKVersion','').rstrip('\\/') != identity['windows_sdk_version']:
            raise RuntimeError('vcvars selected a different compiler/SDK from the frozen build identity')
        command=['cl.exe',*BUILD_FLAGS,f'/I{torch_root / "include"}',
                 f'/I{torch_root / "include/torch/csrc/api/include"}',f'/I{cuda_root / "include"}',
                 str(ROOT/'rwkv/model/csrc/native_launch.cpp'),f'/Fo{destination / "native_launch.obj"}',
                 '/link',f'/OUT:{destination / "native_launch.dll"}',f'/LIBPATH:{torch_root / "lib"}',
                 f'/LIBPATH:{cuda_root / "lib/x64"}','c10.lib','c10_cuda.lib','torch_cpu.lib','torch_cuda.lib','torch.lib','cuda.lib']
        with (args.output/'compile.log').open('w',encoding='utf-8') as log:
            result=subprocess.run(command,cwd=destination,env=environment,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError(f'Native host build failed; inspect {args.output / "compile.log"}')
        metadata={'status':'built','identity':identity,'build_key':key,'command':command,
                  'vcvars':str(vcvars),'VCToolsVersion':environment.get('VCToolsVersion'),
                  'WindowsSDKVersion':environment.get('WindowsSDKVersion'),'binary_sha256':hashlib.sha256((destination/'native_launch.dll').read_bytes()).hexdigest()}
        (destination/'build.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    record={'status':'passed','scope':'MSVC host-only dispatcher/autograd build; no GPU or numerical check',
            'build':metadata,'provenance':process_provenance()}
    (args.output/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','build_key':key,'binary_sha256':metadata['binary_sha256']}))

if __name__=='__main__':main()
