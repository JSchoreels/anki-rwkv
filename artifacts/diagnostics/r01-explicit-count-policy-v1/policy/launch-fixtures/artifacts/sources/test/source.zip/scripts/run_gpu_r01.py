# Synthetic worker, never executed on GPU.
