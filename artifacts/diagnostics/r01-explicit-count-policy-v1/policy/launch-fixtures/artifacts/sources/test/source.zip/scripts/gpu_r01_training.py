# GPU_R01_SHARED_DATA_PATH supported in synthetic fixture.
